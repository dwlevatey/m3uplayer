<header class="admin-header">
    <div class="header-content">
        <div class="header-logo">
            <h2>M3U Streaming</h2>
        </div>
        <div class="header-actions">
            <span class="user-name"><?php echo htmlspecialchars($_SESSION['admin_username']); ?></span>
            <a href="logout.php" class="btn-logout">Sair</a>
        </div>
    </div>
</header>
