<?php
$base_path = dirname(__DIR__);
require_once $base_path . '/config/database.php';
require_once $base_path . '/config/config.php';

// Sanitize input
function sanitize_input($data) {
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return $data;
}

// Check if user is logged in (admin)
function is_admin_logged_in() {
    return isset($_SESSION['admin_id']) && !empty($_SESSION['admin_id']);
}

// Check if client is logged in
function is_client_logged_in() {
    return isset($_SESSION['client_id']) && !empty($_SESSION['client_id']);
}

// Redirect function
function redirect($url) {
    header("Location: " . $url);
    exit();
}

// Generate session token
function generate_session_token() {
    return bin2hex(random_bytes(32));
}

// Build M3U URL
function build_m3u_url($dns_url, $username, $password, $output_format = 'mpegts') {
    $dns_url = rtrim($dns_url, '/');
    
    $url = $dns_url . '/get.php?username=' . urlencode($username) . 
           '&password=' . urlencode($password) . 
           '&type=' . M3U_TYPE . 
           '&output=' . $output_format;
    
    return $url;
}

// Parse M3U content
function parse_m3u_content($content) {
    $lines = explode("\n", $content);
    $channels = [];
    $current_channel = null;
    
    foreach ($lines as $line) {
        $line = trim($line);
        
        if (strpos($line, '#EXTINF:') === 0) {
            // Parse channel info
            $current_channel = [];
            
            // Extract tvg-logo
            if (preg_match('/tvg-logo="([^"]+)"/', $line, $matches)) {
                $current_channel['logo'] = $matches[1];
            }
            
            // Extract tvg-id
            if (preg_match('/tvg-id="([^"]+)"/', $line, $matches)) {
                $current_channel['tvg_id'] = $matches[1];
            }
            
            // Extract group-title (category)
            if (preg_match('/group-title="([^"]+)"/', $line, $matches)) {
                $current_channel['category'] = $matches[1];
            } else {
                $current_channel['category'] = 'Uncategorized';
            }
            
            // Extract channel name (after last comma)
            $parts = explode(',', $line);
            $current_channel['name'] = trim(end($parts));
            
        } elseif (!empty($line) && strpos($line, '#') !== 0 && $current_channel !== null) {
            // This is the stream URL
            $current_channel['url'] = $line;
            $channels[] = $current_channel;
            $current_channel = null;
        }
    }
    
    return $channels;
}

// Group channels by category
function group_channels_by_category($channels) {
    $grouped = [];
    
    foreach ($channels as $channel) {
        $category = $channel['category'] ?? 'Uncategorized';
        
        if (!isset($grouped[$category])) {
            $grouped[$category] = [];
        }
        
        $grouped[$category][] = $channel;
    }
    
    return $grouped;
}

// Format JSON response
function json_response($data, $status = 200) {
    http_response_code($status);
    header('Content-Type: application/json');
    echo json_encode($data);
    exit();
}
?>
