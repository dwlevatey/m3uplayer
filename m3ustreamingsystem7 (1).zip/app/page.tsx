"use client"

import  from "../assets/js/player"

export default function SyntheticV0PageForDeployment() {
  return < />
}
